using System;
using UnityEngine;

namespace VimpireSurvivor.UpgradeSystem.Pickups
{
    public interface IPickup
    {
        public void OnPickup(Transform interactor = null);
    }
    public class PlayerPickupCheck : MonoBehaviour
    {
        [SerializeField]private float checkRadius = 2f;
        [SerializeField]private LayerMask layerMask;
        private Collider[] results = new Collider[10];
        private bool _isdead = false;
        

        private void FixedUpdate()
        {
            if (_isdead) return;
            var size = Physics.OverlapSphereNonAlloc(transform.position, checkRadius, results, layerMask);
            for(int i = 0;i<size;i++)
            {
                if (results[i].TryGetComponent<IPickup>(out var pickup))
                {
                    pickup.OnPickup(transform);
                }
            }
        }


        private void OnDrawGizmos()
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, checkRadius);
        }
        
        public void AddCheckRadius(float amount)
        {
            checkRadius += amount;
        }

        public float GetCheckRadius()
        {
            return checkRadius;
        }

        private void OnEnable()
        {
            MessageCenter.AddListener(MESSAGE_TYPE.PLAYER_DEAD, OnGameOver);
        }

        private void OnDisable()
        {
            MessageCenter.RemoveListener(MESSAGE_TYPE.PLAYER_DEAD, OnGameOver);
        }

        void OnGameOver(Message msg)
        {
            _isdead = true;
        }
    }
}