using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using VimpireSurvivor;
using VimpireSurvivor.UpgradeSystem.Pickups;
using Random = UnityEngine.Random;

public class Coin : MonoBehaviour,IRecyclable,IPickup
{

    public PoolType PoolType => PoolType.Coin;
    public GameObject GameObject => gameObject;
    private Tweener tweener;
    [SerializeField]private float _followSpeed;
    private bool _canFollow = false;
    private Transform _target;

    public void OnSpawn()
    {
        if (this.tweener != null)
        {
            tweener.Kill();
            tweener = null;
        }
        float randomDuration = Random.Range(0.5f, 1f);
        float randomHeight = Random.Range(0.5f, 1f);
        Vector3 targetPosition = transform.position + new Vector3(0, randomHeight, 0);
        tweener = transform.DOMove(targetPosition, randomDuration)
            .SetEase(Ease.OutQuad)
            .SetLoops(-1, LoopType.Yoyo);
    }

    public void OnRecycle()
    {
        tweener?.Kill();
        tweener = null;
        _target = null;
        _canFollow = false;
    }
    
    private void Update()
    {
        if (_canFollow)
        {
            Vector3 direction = (_target.position - transform.position).normalized;
            transform.position += direction * (_followSpeed * Time.deltaTime);
        }
    }

    public void OnPickup(Transform interactor = null)
    {
        
        if(_canFollow) return;
        if (interactor is not null)
        {
            _target = interactor;
            _canFollow = true;
            tweener.Pause();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            PoolManager.Instance.coinPool.Recycle(this);
            MessageCenter.SendMessage(MESSAGE_TYPE.COIN_COLLECTED, new Message
            {
                val = 10
            });
        }
    }
}
