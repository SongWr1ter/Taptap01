using System;
using UnityEngine;
using VimpireSurvivor.BattleControl;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    public class UpgradePanelUI : MonoBehaviour
    {
        private GameObject _upgradeItemPrefab;
        private UpgradeItemUI[] _upgradeItemUIs = new UpgradeItemUI[3];
        private string _upgradeItemPrefabPath = "Prefabs/UI/UpgradeItemUI";
        private CanvasGroup _canvasGroup;
        private void Awake()
        {
            _upgradeItemPrefab = Resources.Load<GameObject>(_upgradeItemPrefabPath);
            for (int i = 0; i < 3; i++)
            {
                var item = Instantiate(_upgradeItemPrefab, transform);
                _upgradeItemUIs[i] = item.GetComponent<UpgradeItemUI>();
            }
            _canvasGroup = GetComponent<CanvasGroup>();
            CloseMenu();
        }

        public void ShowMenu()
        {
            _canvasGroup.alpha = 1;
            _canvasGroup.blocksRaycasts = true;
            _canvasGroup.interactable = true;
        }

        public void CloseMenu()
        {
            _canvasGroup.alpha = 0;
            _canvasGroup.blocksRaycasts = false;
            _canvasGroup.interactable = false;
            foreach (var itemUI in _upgradeItemUIs)
            {
                itemUI.Clearup();
            }
            MessageCenter.SendMessage(MESSAGE_TYPE.UPGRADE_MENU_CLOSED, MessageCenter.EmptyMessage);
        }
        
        public void ConfigureUpgradeItems(ItemData[] upgradeItems, PlayerStat playerStat)
        {
            for (int i = 0; i < _upgradeItemUIs.Length; i++)
            {
                if (i < upgradeItems.Length)
                {
                    var itemData = upgradeItems[i];
                    int weaponLevelId = playerStat.GetWeaponLevelId(itemData.GetWeaponType());
                    _upgradeItemUIs[i].Configure(itemData.itemName, itemData.GetNextDescription(weaponLevelId), itemData.itemIcon, () =>
                    {
                        foreach (var logic in itemData.itemLogic)
                        {
                            logic.DoItemLogic(playerStat);
                        }
                        GetComponentInParent<UpgradePanelUI>().CloseMenu();
                    });
                    _upgradeItemUIs[i].gameObject.SetActive(true);
                }
                else
                {
                    _upgradeItemUIs[i].gameObject.SetActive(false);
                }
            }
        }
    }
}