using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using VimpireSurvivor.BattleControl;
using VimpireSurvivor.Player;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    public class PlayerUpgrade : MonoBehaviour
    {
        [Header("# Level data")]
           public List<int> requiredCoinsPerLevel;
        private int _currentLevel = -1;
        private int _currentCoins;
        private int _requiredCoins;
        private float _coinBenefitMultiplier = 1f;
        private List<ItemData> _candidateUpgradeItems = new List<ItemData>();
        private Dictionary<ItemData, int> _upgradeItemPurchaseTimes = new Dictionary<ItemData, int>();
        private PlayerStat _playerStat;
        private bool _isdead;

        private PlayerStat playerStat
        {
            get
            {
                if (_playerStat == null)
                {
                    _playerStat = GetComponent<PlayerCharacter>().GetPlayerStat();
                }
                return _playerStat;
            }
        }
        [SerializeField]private AssetLabelReference upgradeItemLabel;

        private void Awake()
        {
            Addressables.InitializeAsync();
            LoadUpgradeSystems();
        }

        void LoadUpgradeSystems()
        {
            Addressables.LoadAssetsAsync<ItemData>(upgradeItemLabel, (data) =>
            {
                _candidateUpgradeItems.Add(data);
                _upgradeItemPurchaseTimes.Add(data, data.maxPurchaseCount-1);//-1时因为石山算法导致的
            });
        }

        private void Start()
        {
            _currentCoins = 0;
            _requiredCoins = NextLevelRequiredCoins();
            UpdateUI();
            AddDefaultWeapon();
        }

        private void OnEnable()
        {
            MessageCenter.AddListener(MESSAGE_TYPE.COIN_COLLECTED, OnCoinCollected);
            MessageCenter.AddListener(MESSAGE_TYPE.PLAYER_DEAD, OnGameOver);
        }

        private void OnDisable()
        {
            MessageCenter.RemoveListener(MESSAGE_TYPE.COIN_COLLECTED, OnCoinCollected);
            MessageCenter.RemoveListener(MESSAGE_TYPE.PLAYER_DEAD, OnGameOver);
        }
        
        private void OnCoinCollected(Message message)
        {
            if(_isdead) return;
            try
            {
                SoundManager.PlayAudio("coin");
                if (AddCoin(message.val))
                {
                    _requiredCoins = NextLevelRequiredCoins();
                    UpgradeLevel();
                }
                UpdateUI();
            }
            catch (Exception e)
            {
                LogPanel.Instance.Log(e.ToString());
                throw;
            }
            
        }
        
        private void UpgradeLevel()
        {
            // Level up logic can be added here
            MessageCenter.SendMessage(MESSAGE_TYPE.UPGRADE, new Message{val = _currentLevel});
            // 随机抽取3个升级选项,不重复
            HashSet<int> cachedIndices = new HashSet<int>();
            int maxItem = Mathf.Min(3, _candidateUpgradeItems.Count);
            int removeIndex = -1;
            for (int i = 0; i < maxItem; ++i)
            {
                int index = UnityEngine.Random.Range(0, _candidateUpgradeItems.Count);
                while (cachedIndices.Contains(index))
                {
                    index = UnityEngine.Random.Range(0, _candidateUpgradeItems.Count);
                }
                cachedIndices.Add(index);
                if (_upgradeItemPurchaseTimes[_candidateUpgradeItems[index]] > 0)
                {
                    _upgradeItemPurchaseTimes[_candidateUpgradeItems[index]]--;
                    if(_upgradeItemPurchaseTimes[_candidateUpgradeItems[index]] == 0)
                    {
                        removeIndex = index;
                    }
                }
            }
            
            // 从cachedIndices中获取ItemData数组
            ItemData[] upgradeItems = new ItemData[cachedIndices.Count];
            int j = 0;
            foreach (var index in cachedIndices)
            {
                upgradeItems[j++] = _candidateUpgradeItems[index];
            }
            UIManager.Instance.UpgradePanelUI.ConfigureUpgradeItems(upgradeItems, playerStat);
            UIManager.Instance.UpgradePanelUI.ShowMenu();
            MessageCenter.SendMessage(MESSAGE_TYPE.UPGRADE_MENU_OPENED, MessageCenter.EmptyMessage);
            if (removeIndex >= 0)
            {
                _candidateUpgradeItems.RemoveAt(removeIndex);
            }
        }

        private bool AddCoin(int coin)
        {
            coin = Mathf.RoundToInt(coin * _coinBenefitMultiplier);
            _currentCoins += coin;
            if (_currentCoins >= _requiredCoins && _requiredCoins > 0)
            {
                _currentCoins = 0;
                return true;
            }

            return false;
        }
        
        private int NextLevelRequiredCoins()
        {
            if (_currentLevel+1 < requiredCoinsPerLevel.Count)
            {
                return requiredCoinsPerLevel[++_currentLevel];
            }
            else
            {
                _currentLevel++;
            }
            return -1;
        }

        private void UpdateUI()
        {
            UIManager.Instance.PlayerLevelUIPanel.UpdateLevelUI(_currentLevel, _currentCoins, _requiredCoins);
        }

        public float GetCoinBenefitMultiplier()
        {
            return _coinBenefitMultiplier;
        }
        
        public void SetCoinBenefitMultiplier(float value)
        {
            _coinBenefitMultiplier = value;
        }
        
        void OnGameOver(Message msg)
        {
            _isdead = true;
        }

        public void AddDefaultWeapon()
        {
            GetComponent<PlayerCharacter>().AddNewAttack(AttackBulletType.FireBall);
            foreach (var itemData in _candidateUpgradeItems)
            {
                if(itemData.GetWeaponType() == AttackBulletType.FireBall)
                {
                    _upgradeItemPurchaseTimes[itemData]--;
                    break;
                }
            }
        }
    }
}