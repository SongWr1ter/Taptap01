using System;
using System.Collections.Generic;
using UnityEngine;
using VimpireSurvivor.BattleControl;
using VimpireSurvivor.Player;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    [CreateAssetMenu(menuName = "Upgrade System/ItemLogic/WeaponUpgrade",fileName = "ItemLogic")]
    public class WeaponUpgrade : ItemLogic
    {
        public AttackBulletType weaponUpgradeType;
        public override void DoItemLogic(PlayerStat playerStat)
        {
            if (playerStat == null)
            {
                return;
            }
            playerStat.WeaponNextLevel(weaponUpgradeType);
        }
    }
}