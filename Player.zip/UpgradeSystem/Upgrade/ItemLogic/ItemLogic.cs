using Sirenix.OdinInspector;
using UnityEngine;
using VimpireSurvivor.BattleControl;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    public abstract class ItemLogic : ScriptableObject
    {
        public abstract void DoItemLogic(PlayerStat playerStat);
    }
    
    public class EmptyItemLogic : ItemLogic
    {
        public override void DoItemLogic(PlayerStat playerStat)
        {
            // Do nothing
        }
    }

   

}