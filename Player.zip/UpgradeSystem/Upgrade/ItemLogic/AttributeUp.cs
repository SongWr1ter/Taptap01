using System;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;
using VimpireSurvivor.BattleControl;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    [CreateAssetMenu(menuName = "Upgrade System/ItemLogic/AttributeUp",fileName = "ItemLogic")]
        public class AttributeUp : ItemLogic
        {
            public enum AttributeUpgradeType
            {
                Health_Up,
                Max_Health_Up,
                Damage_Up,
                Shot_Speed_Up,
                Move_Speed_Up,
                Pickup_Radius_Up,
                Coin_Benefit_Up,
            }

            private static readonly Dictionary<AttributeUpgradeType, Action<PlayerStat,float>> attributeUps;

            static AttributeUp()
            {
                attributeUps = new()
                {
                    { AttributeUpgradeType.Health_Up, (ps, v) => ps.HealthUp(v) },
                    { AttributeUpgradeType.Max_Health_Up, (ps, v) => ps.HealthMaxUp(v) },
                    { AttributeUpgradeType.Damage_Up, (ps, v) => ps.AttackDamageUp(v) },
                    { AttributeUpgradeType.Shot_Speed_Up, (ps, v) => ps.ShotSpeedUp(v) },
                    { AttributeUpgradeType.Move_Speed_Up, (ps, v) => ps.MoveSpeedUp(v) },
                    { AttributeUpgradeType.Pickup_Radius_Up, (ps, v) => ps.PickupRadiusUp(v) },
                    { AttributeUpgradeType.Coin_Benefit_Up, (ps, v) => ps.CoinBenefitUp(v) },
                };
            }
            [InfoBox("相对值，0.1 = +10%,除了攻击力是直接加成数值")]
            public float amount = 0.1f;
            public AttributeUpgradeType attributeUpgradeType;
            public override void DoItemLogic(PlayerStat playerStat)
            {
                if (playerStat is null) return;
                if (attributeUps.TryGetValue(attributeUpgradeType, out var action))
                {
                    action(playerStat, amount);
                }
                else
                {
                    Debug.LogWarning($"未定义的升级类型: {attributeUpgradeType}");
                }
            }
        }
}