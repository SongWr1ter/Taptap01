using System.Collections.Generic;
#if UNITY_EDITOR
using Sirenix.OdinInspector;
using Sirenix.Reflection.Editor;
# endif
using UnityEngine;
using VimpireSurvivor.Player;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    [CreateAssetMenu(fileName = "New Item Data", menuName = "Upgrade System/Item Data", order = 0)]
    public class ItemData : ScriptableObject
    {
        
        public enum ItemType
        {
            AttributeUp,
            NewWeapon,
            SpecialAbility,
        }

        [Header("# Main Info")] public ItemType itemType;
        public static int itemIdCounter = 0;
        public string itemName;
        #if UNITY_EDITOR
        [ShowIf("@itemType != ItemType.NewWeapon")]
        #endif
        public string itemDescription;
#if UNITY_EDITOR
        [ShowIf("@itemType == ItemType.NewWeapon")]
        [TextArea(3,10)]
        [ValidateIlIf("@itemType == ItemType.NewWeapon")]
        [ValidateInput("@_weaponDataConfigure != null && itemDescriptions.Count == _weaponDataConfigure.configureItems.Count")]
        # endif
        public List<string> itemDescriptions;
        public Sprite itemIcon;
        public List<ItemLogic> itemLogic;

        public int maxPurchaseCount
        {
            get
            {
                if (itemType == ItemType.AttributeUp) return -1;
                #region 丑陋的缓存写法
                if (itemType == ItemType.NewWeapon)
                {
                    return _weaponDataConfigure.configureItems.Count;
                }
                #endregion

                return -1;
            }
        }
        private int _max_count_ = -1;
        #if UNITY_EDITOR
        [ShowIf("@itemType == ItemType.NewWeapon")]
        [InfoBox("对不起，但史山的要求不能为空")]
        #endif
        [SerializeField]
        private PlayerAttackDataConfigure _weaponDataConfigure;

        public string GetNextDescription(int _cur_index_)
        {
            if (itemType != ItemType.NewWeapon) return itemDescription;
            if (_cur_index_+1 >= itemDescriptions.Count) return itemDescriptions[itemDescriptions.Count - 1];
            return itemDescriptions[_cur_index_ + 1];
        }
        
        public AttackBulletType GetWeaponType()
        {
            if (_weaponDataConfigure == null)
            {
                return AttackBulletType.None;
            }
            return _weaponDataConfigure.bulletType;
        }
    }
}