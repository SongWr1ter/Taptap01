using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace VimpireSurvivor.UpgradeSystem.Upgrade
{
    public class UpgradeItemUI : MonoBehaviour
    {
        private Button _button;
        private TMP_Text _nameText;
        private TMP_Text _descriptionText;
        private Image _icon;


        private void Awake()
        {
            _button = GetComponent<Button>();
            var texts = GetComponentsInChildren<TMP_Text>();
            _nameText = texts[0];
            _descriptionText = texts[2];
            _icon = GetComponentsInChildren<Image>()[1];
        }
        
        public void Configure(string name, string description, Sprite icon, Action onClick)
        {
            _nameText.text = name;
            _descriptionText.text = description;
            _icon.sprite = icon;
            _button.onClick.AddListener(() => onClick?.Invoke());
        }

        public void Clearup()
        {
            _button.onClick.RemoveAllListeners();
        }
    }
}