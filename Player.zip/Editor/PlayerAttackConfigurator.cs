using System.Collections.Generic;
using System.IO;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using UnityEditor;
using UnityEngine;
using VimpireSurvivor.Player;

namespace VimpireSurvivor.Editor
{
    public class PlayerAttackConfigurator : OdinEditorWindow
    {
        [MenuItem("VimpireSurvivor/攻击数据配置器")]
        private static void OpenWindow()
        {
            GetWindow<PlayerAttackConfigurator>("攻击数据配置器").Show();
        }
        
        [Title("ConfigureData")]
        [BoxGroup("主配置信息")]
        [LabelText("目标配置文件")]
        [InlineEditor(ObjectFieldMode = InlineEditorObjectFieldModes.Boxed)]
        public PlayerAttackDataConfigure targetConfig;
        
        //当加载了目标配置文件时，显示删除旧数据按钮
        [BoxGroup("主配置信息")]
        [ShowIf("@targetConfig != null")]
        [Button("删除旧数据", ButtonSizes.Large), GUIColor(1, 0, 0)]
        private void DeleteOldData()
        {
            if (targetConfig == null || targetConfig.configureItems == null)
            {
                EditorUtility.DisplayDialog("错误", "目标配置文件或其数据项为空，无法删除旧数据！", "确定");
                return;
            }
            if (EditorUtility.DisplayDialog("确认删除", "此操作将删除目标配置文件中的所有旧数据，是否继续？", "是", "否"))
            {
                // 删除旧的
                foreach (var oldItem in targetConfig.configureItems)
                {
                    string oldItemPath = AssetDatabase.GetAssetPath(oldItem);
                    if (AssetDatabase.DeleteAsset(oldItemPath))
                    {
                        Debug.Log($"Deleted old item asset at: {oldItemPath}");
                    }
                }
                targetConfig.configureItems.Clear();
                EditorUtility.SetDirty(targetConfig);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }
        }

        [BoxGroup("主配置信息")]
        [ShowIf("@targetConfig != null")]
        [Button("把数据导入下方列表", ButtonSizes.Medium, Expanded = true), GUIColor(1, 1, 0)]
        private void ImportFromConfig()
        {
            pendingItems.Clear();
            if (targetConfig.configureItems == null || targetConfig.configureItems.Count == 0)
            {
                EditorUtility.DisplayDialog("提示", "目标配置文件中没有数据项可导入！", "确定");
                return;
            }
            foreach (var item in targetConfig.configureItems)
            {
                ItemTemplate newItem = new ItemTemplate
                {
                    shotSpeed = item.attackInterval > 0 ? 1.0f / item.attackInterval : 1.0f,
                    baseDamage = item.baseDamage,
                    basePiercingCount = item.basePiercingCount,
                    continueAttackCount = item.continueAttackCount
                };
                pendingItems.Add(newItem);
            }
        }

        [BoxGroup("主配置信息")]
        [HorizontalGroup("主配置信息/Create")]
        [Button("创建新配置文件", ButtonSizes.Large), GUIColor(0, 1, 0)]
        private void CreateNewConfig()
        {
            string path = EditorUtility.SaveFilePanelInProject("创建攻击配置", "NewAttackConfigure", "asset", "请选择保存路径");
            if (string.IsNullOrEmpty(path)) return;

            PlayerAttackDataConfigure newConfig = CreateInstance<PlayerAttackDataConfigure>();
            AssetDatabase.CreateAsset(newConfig, path);
            AssetDatabase.SaveAssets();
            targetConfig = newConfig;
        }

        [Space(50)]
        [Title("ConfigureDataItem")]
        [InfoBox("在此处编辑的所有 Item 会在保存时自动生成资源文件并导入到上方的配置文件中")]
        [ListDrawerSettings(ShowIndexLabels = true, DraggableItems = true, ShowFoldout = true,AddCopiesLastElement =  true)]
        [LabelText("待导入的 Item 列表")]
        public List<ItemTemplate> pendingItems = new List<ItemTemplate>();

        [Button("保存并导入到主配置", ButtonSizes.Gigantic), GUIColor(0.4f, 0.8f, 1)]
        private void SaveAndImport()
        {
            if (targetConfig == null)
            {
                EditorUtility.DisplayDialog("错误", "请先选择或创建一个目标配置文件！", "确定");
                return;
            }

            // 获取主配置文件的目录
            string folderPath = Path.GetDirectoryName(AssetDatabase.GetAssetPath(targetConfig));
            string subFolderName = $"{targetConfig.name}_Items";
            string fullFolderPath = Path.Combine(folderPath, subFolderName);

            // 如果文件夹不存在则创建
            if (!AssetDatabase.IsValidFolder(fullFolderPath))
            {
                AssetDatabase.CreateFolder(folderPath, subFolderName);
            }

            if (targetConfig.configureItems == null)
                targetConfig.configureItems = new List<PlayerAttackDataConfigureItem>();
            else
            {
                // 确保不会重复添加已有的配置项
                foreach (var existingItem in targetConfig.configureItems)
                {
                    string existingItemPath = AssetDatabase.GetAssetPath(existingItem);
                    if (AssetDatabase.LoadAssetAtPath<PlayerAttackDataConfigureItem>(existingItemPath) != null)
                    {
                        Debug.LogWarning($"配置项已存在，跳过添加: {existingItemPath}");
                    }
                }
            }

            foreach (var itemData in pendingItems)
            {
                // 创建 ScriptableObject 实例
                PlayerAttackDataConfigureItem newItem = CreateInstance<PlayerAttackDataConfigureItem>();
                newItem.attackInterval = 1.0f / itemData.shotSpeed;
                newItem.baseDamage = itemData.baseDamage;
                newItem.basePiercingCount = itemData.basePiercingCount;
                newItem.continueAttackCount = itemData.continueAttackCount;

                // 生成唯一文件名
                string fileName = $"{targetConfig.bulletType}_LV{targetConfig.configureItems.Count + 1}.asset";
                string assetPath = Path.Combine(fullFolderPath, fileName);

                // 保存资源
                AssetDatabase.CreateAsset(newItem, assetPath);
                
                // 添加到主配置
                targetConfig.configureItems.Add(newItem);
            }

            // 标记脏数据并保存
            EditorUtility.SetDirty(targetConfig);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            // 清空列表
            pendingItems.Clear();
            EditorUtility.DisplayDialog("Finish", "所有配置项已成功生成并导入！", "确定");
        }

        /// <summary>
        /// 用于在编辑器窗口中临时显示和编辑的数据结构
        /// </summary>
        [System.Serializable]
        public class ItemTemplate
        {
            [HorizontalGroup("G0")] [LabelText("射速，每秒发射几发")]
            [ValidateInput("@shotSpeed > 0", "射速必须大于0")] 
            public float shotSpeed = 1f;
            [HorizontalGroup("G1")] [LabelText("基础伤害")] public int baseDamage = 5;
            [HorizontalGroup("G2")] [LabelText("穿透次数")] public int basePiercingCount = 1;
            [HorizontalGroup("G2")] [LabelText("连发次数")] public int continueAttackCount = 1;
        }
    }
}