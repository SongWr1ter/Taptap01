using System.Collections.Generic;
using UnityEngine;

namespace VimpireSurvivor.Player
{
    [CreateAssetMenu(fileName = "AttackConfigure", menuName = "Attacks/Configure", order = 0)]
    public class PlayerAttackDataConfigure : ScriptableObject
    {
        public AttackBulletType bulletType;
        public float attackRadius;
        public List<PlayerAttackDataConfigureItem> configureItems;
        
    }
}