using UnityEngine;

namespace VimpireSurvivor.Player
{
    public enum AttackBulletType
    {
        FireBall,
        ShotGun,
        None,
    }
    public struct AttackSpawnData
    {
        public AttackBulletType bulletType;
        public int damage;
        public Vector3 spawnPos;
        public Quaternion spawnRotation;
        public int piercingCount;
    }
    public class PlayerAttack
    {
        protected PlayerCharacter player;
        protected Collider[] _colliders;
        protected LayerMask attackFilterLayer;
        protected float attackRadius;
        protected Transform attackPos;
        protected bool _canAttack;
        protected float _attackInterval;
        protected float _attackTimer;
        protected AttackBulletType _attackBulletType;
        protected PlayerAttackDataConfigure _cacheConfigure;
        protected PlayerAttackDataConfigureItem _currentConfigureItem;
        protected int _maxAttackLevel;
        protected int _currentAttackLevel;

        public virtual void OnUpdate(float deltaTime)
        {
            if (!_canAttack)
            {
                _attackTimer += deltaTime;
                if ( _attackTimer >= _attackInterval)
                {
                    _canAttack = true;
                    _attackTimer = 0f;
                }
            }
            else
            {
                Attack();
            }
        }

        public virtual void Attack()
        {
        }

        public PlayerAttack(PlayerAttackDataConfigure configure, 
            PlayerCharacter player,Collider[] colliders, LayerMask filterLayer,Transform attackPos)
        {
            this.player = player;
            _colliders = colliders;
            attackFilterLayer = filterLayer;
            _cacheConfigure = configure;
            attackRadius = _cacheConfigure.attackRadius;
            this.attackPos = attackPos;
            _attackBulletType = _cacheConfigure.bulletType;
            
            _maxAttackLevel = _cacheConfigure.configureItems.Count;
            _currentAttackLevel = 0;
            _currentConfigureItem = _cacheConfigure.configureItems[_currentAttackLevel];
            _attackInterval = _currentConfigureItem.attackInterval;
        }
        
        public void UpdateAttackInterval(float factor)
        {
            _attackInterval /= factor;
        }

        public void NextAttackLevel()
        {
            if(_currentAttackLevel + 1 < _maxAttackLevel)
            {
                _currentAttackLevel++;
                _currentConfigureItem = _cacheConfigure.configureItems[_currentAttackLevel];
                _attackInterval = _currentConfigureItem.attackInterval;
            }
            #if UNITY_EDITOR
            else
            {
                LogPanel.Instance.Log("Attack already at max level");
            }
            #endif
        }
    }
    
    public class MagicBallAttack : PlayerAttack
    {
        
        private float _baseShotInterval = 0.1f;
        private float _continueShootingTimer = 0f;
        private bool _continueShooting = false;
        private Vector3 _targetPos;
        private Quaternion _targetRotation;
        private int _shotBulletCount = 0;
        public MagicBallAttack(PlayerAttackDataConfigure configure, 
            PlayerCharacter player,Collider[] colliders,Transform attackPos,LayerMask filterLayer) 
            : base(configure, player, colliders, filterLayer, attackPos)
        {
            
        }

        public override void OnUpdate(float deltaTime)
        {
            base.OnUpdate(deltaTime);
            if (_continueShooting)
            {
                if (_shotBulletCount < _currentConfigureItem.continueAttackCount)
                {
                    _continueShootingTimer += deltaTime;
                    if (_continueShootingTimer >= _baseShotInterval)
                    {
                        Shoot();
                        _continueShootingTimer = 0f;
                        _shotBulletCount++;
                    }
                }
            }
        }

        public override void Attack()
        {
                int hitCount = Physics.OverlapSphereNonAlloc(attackPos.position, attackRadius, _colliders, attackFilterLayer);
                if (hitCount > 0)
                {
                    // get closet enemy
                    float distance = float.MaxValue;
                    Transform target = null;
                    for (int i = 0;i<hitCount;i++)
                    {
                        var col = _colliders[i];
                        float d = Vector3.Distance(attackPos.position, col.transform.position);
                        if (d <= distance)
                        {
                            target = col.transform;
                            distance = d;
                        }
                    }
                    // shot
                    if (target is not null)
                    {
                        _canAttack = false;
                        _targetPos = target.position;
                        ContinueShoot();
                    }
                }
        }

        private void ContinueShoot()
        {
            _continueShooting= true;
            _shotBulletCount = 0;
            _continueShootingTimer = 0f;
            
            Vector3 dir = _targetPos - attackPos.position;
            dir.y = 0;
            _targetRotation = Quaternion.LookRotation(dir.normalized);
        }

        private void Shoot()
        {
            PoolManager.Instance.SpawningAttack(new AttackSpawnData
            {
                bulletType = _attackBulletType,
                damage = Mathf.RoundToInt(_currentConfigureItem.baseDamage + player.GetPlayerStat().DamageFactor),
                spawnPos = attackPos.position,
                spawnRotation = _targetRotation,
                piercingCount = _currentConfigureItem.basePiercingCount
            });
        }
    }
}