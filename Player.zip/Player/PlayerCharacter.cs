using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;
using VimpireSurvivor;
using VimpireSurvivor.BattleControl;
using VimpireSurvivor.Player;

public class PlayerCharacter : MonoBehaviour,IDamageable
{
    private PlayerInputControls inputControl;
    private Vector2 inputDirection;
    [SerializeField]private float speed = 5f;
    [SerializeField]private float rotateSpeed = 5f;
    private Rigidbody rb;
    private Animator anim;

    #region AttackProperties

    [Header("攻击属性")] 
    [SerializeField,InfoBox("需手动拖拽")]private List<PlayerAttackDataConfigure> _allAttacks;
    private List<PlayerAttack> _attacks = new List<PlayerAttack>();
    private Dictionary<AttackBulletType, PlayerAttack> _attackDict = new();
    private Dictionary<AttackBulletType,int> _attackLevelDict = new();
    [InfoBox("当前拥有的攻击类型，用于UI显示"),ShowInInspector]
    public readonly List<AttackBulletType> _attackShows = new();
    [SerializeField,Tooltip("无实际意义，纯调试用")]private float attackRadius;
    [SerializeField]private LayerMask attackFilterLayer;
    private Collider[] _colliders = new Collider[64];
    [SerializeField] private Transform attackPos;

    #endregion
    #region StatsProperties
    [SerializeField] private int maxHealth;
    [SerializeField] private GameObject healthUIObject;
    private PlayerStat _stat;
    private PlayerHealthUI _healthUI;
    private Canvas _selfCanvas;
    
    private bool _isDead = false;
    #endregion
    
    private void Awake()
    {
        // 初始化输入控制
        inputControl = new PlayerInputControls();
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();

        _selfCanvas = GetComponentInChildren<Canvas>();
        _healthUI = Instantiate(healthUIObject).GetComponent<PlayerHealthUI>();
        _healthUI.transform.SetParent(_selfCanvas.transform);
    }
    private void OnEnable()
    {
        // 启用输入控制
        inputControl.Enable();
        _stat = new PlayerStat(maxHealth, OnHealthChange, OnDead, OnMaxHealthChange,this);
    }

    private void Start()
    {
        _stat.SetHealth2Max();
    }

    private void OnDisable()
    {
        // 禁用输入控制
        inputControl.Disable();
    }
    private void Update()
    {
        if(_isDead) return;
        // 获取输入方向
        inputDirection = inputControl.Player.Move.ReadValue<Vector2>();
        
        
    }
    private void FixedUpdate()
    {
        if(_isDead) return;
        Move();
        AnimationUpdate();
        if (_attacks.Count > 0)
        {
            foreach (var playerAttack in _attacks)
            {
                playerAttack.OnUpdate(Time.deltaTime);
            }
        }
    }

    private void AnimationUpdate()
    {
        anim.SetFloat("Speed", inputDirection.magnitude);
    }

    //移动角色
    private void Move()
    {
        // 根据输入方向移动角色
        rb.velocity = new Vector3(inputDirection.x * speed ,
            rb.velocity.y,
            inputDirection.y * speed );
        // 根据输入方向旋转角色
        if (inputDirection.x != 0 || inputDirection.y != 0)
        {
            Vector3 inputDir = new Vector3(inputDirection.x, 0, inputDirection.y).normalized;
            Quaternion targetRotation = Quaternion.LookRotation(inputDir);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotateSpeed );

        }
    }

    

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position,attackRadius);
    }
    
    private void OnHealthChange(int oldValue, int newValue)
    {
        _healthUI.UpdateHealthUI(newValue, _stat.GetMaxHealth());
    }
    
    private void OnMaxHealthChange(int oldValue, int newValue)
    {
        
    }

    private void OnDead()
    {
        _isDead = true;
        anim.SetBool("Dead",true);
        MessageCenter.SendMessage(MESSAGE_TYPE.PLAYER_DEAD,MessageCenter.EmptyMessage);
    }

    public void TakeDamage(int damage)
    {
        _stat.TakeDamage(damage);
    }

    public void UpdateMoveSpeed(float speed)
    {
        this.speed = speed;
    }

    public float GetMoveSpeed()
    {
        return speed;
    }
    
    public PlayerStat GetPlayerStat()
    {
        return _stat;
    }

    private void AddNewAttack(PlayerAttackDataConfigure conf)
    {
        _attackShows.Add(conf.bulletType);
        if (conf.bulletType == AttackBulletType.FireBall)
        {
            var attack = new MagicBallAttack(conf, this,_colliders, attackPos, attackFilterLayer);
            _attacks.Add(attack);
            _attackDict.Add(conf.bulletType,attack);
            _attackLevelDict.Add(conf.bulletType,0);
        }
    }
    
    public void AddNewAttack(AttackBulletType type)
    {
        // 防护工作在public里做
        if (_attackDict.ContainsKey(type))
        {
            return;
        }
        foreach (var conf in _allAttacks)
        {
            if (conf.bulletType == type)
            {
                AddNewAttack(conf);
                break;
            }
        }
    }
    
    public List<PlayerAttack> GetAllAttacks()
    {
        return _attacks;
    }

    public void AttackUpgrade(AttackBulletType type)
    {
        if (_attackDict.ContainsKey(type))
        {
            _attackDict[type].NextAttackLevel();
            _attackLevelDict[type]++;
        }
    }
    
    public int GetWeaponLevelId(AttackBulletType type)
    {
        if (_attackLevelDict.ContainsKey(type))
        {
            return _attackLevelDict[type];
        }

        return 0;
    }
}
