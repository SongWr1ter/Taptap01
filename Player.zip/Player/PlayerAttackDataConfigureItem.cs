using UnityEngine;

namespace VimpireSurvivor.Player
{
    [CreateAssetMenu(fileName = "new item", menuName = "Attacks/ConfigureItem", order = 1)]
    public class PlayerAttackDataConfigureItem : ScriptableObject
    {
        public float attackInterval;
        public int baseDamage;
        public int basePiercingCount;
        public int continueAttackCount;
    }
}