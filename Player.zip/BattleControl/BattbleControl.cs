using System;
using System.Collections.Generic;
using UnityEngine;
using VimpireSurvivor.Player;
using VimpireSurvivor.UpgradeSystem.Pickups;
using VimpireSurvivor.UpgradeSystem.Upgrade;

namespace VimpireSurvivor.BattleControl
{
    public interface IDamageable
    {
        public void TakeDamage(int damage);
    }

    public class CharacterStat
    {
        protected const int MAX_HEALTH = 1000;
        protected int MaxHealth { get; set; }
        protected int _currentHealth;
        
        protected Action<int,int> _onHealthChange;
        protected Action  _onDead;
        protected Action<int,int>  _onMaxHealthChange;

        protected void AddHealth(int amount)
        {
            int oldHealth = _currentHealth;
            _currentHealth = Math.Clamp(_currentHealth + amount,0, MaxHealth);
            OnHealthChange(oldHealth, _currentHealth);
        }

        public void AddMaxHealth(int amount)
        {
            OnMaxHealthChange(MaxHealth, MaxHealth + amount);
            MaxHealth = Math.Clamp(MaxHealth + amount, 1, MAX_HEALTH);
            if (_currentHealth > MaxHealth)
            {
                _currentHealth = MaxHealth;
            }
        }
        
        protected void OnHealthChange(int oldValue, int newValue)
        {
            _onHealthChange?.Invoke(oldValue, newValue);
            if (newValue <= 0)
            {
                OnDead();
            }
        }

        protected void OnDead()
        {
            _onDead?.Invoke();
        }

        protected void OnMaxHealthChange(int oldValue, int newValue)
        {
            _onMaxHealthChange?.Invoke(oldValue, newValue);
        }

        public void TakeDamage(int damage)
        {
            AddHealth(-damage);
        }

        public void Heal(int amount)
        {
            AddHealth(amount);
        }

        public void SetHealth2Max()
        {
            OnHealthChange(0, MaxHealth);
            _currentHealth = MaxHealth;
        }
        
        public CharacterStat(int maxHealth, Action<int,int> onHealthChange, Action onDead, Action<int,int> onMaxHealthChange)
        {
            MaxHealth = maxHealth;
            _onHealthChange = onHealthChange;
            _onDead = onDead;
            _onMaxHealthChange = onMaxHealthChange;
        }

        public int GetCurrentHealth()
        {
            return _currentHealth;
        }
        
        public int GetMaxHealth()
        {
            return MaxHealth;
        }
    }
    
    public class PlayerStat : CharacterStat
    {

        private float _shotSpeedFactor = 1f;
        private float _damageFactor = 0f;
        public float DamageFactor => _damageFactor;
        private float _pickupRadiusFactor = 1f;
        private float _speedFactor = 1f;
        private float _coinBenifitFactor = 1f;
        private PlayerCharacter _playerCharacter;
        
        
        public PlayerStat(int maxHealth, 
            Action<int, int> onHealthChange, 
            Action onDead, 
            Action<int, int> onMaxHealthChange,PlayerCharacter player) : base(maxHealth, onHealthChange, onDead, onMaxHealthChange)
        {
            _playerCharacter = player;
        }

        public void HealthUp(float val)
        {
            float amount = MaxHealth * val;
            Heal(Mathf.RoundToInt(amount));
        }
        
        public void HealthMaxUp(float val)
        {
            AddMaxHealth(Mathf.RoundToInt(val * MaxHealth));
            float amount = MaxHealth * 0.1f;
            Heal(Mathf.RoundToInt(amount));
        }

        public void MoveSpeedUp(float val)
        {
            _speedFactor += val * _speedFactor;
            _playerCharacter.UpdateMoveSpeed(_speedFactor * _playerCharacter.GetMoveSpeed());
        }

        public void ShotSpeedUp(float val)
        {
            _shotSpeedFactor += val * _shotSpeedFactor;
            foreach (var playerAttack in _playerCharacter.GetAllAttacks())
            {
                playerAttack.UpdateAttackInterval(_shotSpeedFactor);
            }
        }

        public void AttackDamageUp(float val)
        {
            _damageFactor += val;
        }

        public void PickupRadiusUp(float val)
        {
            if(_playerCharacter.TryGetComponent(out PlayerPickupCheck pickupCheck))
            {
                _pickupRadiusFactor += val * _pickupRadiusFactor;
                pickupCheck.AddCheckRadius(pickupCheck.GetCheckRadius() * _pickupRadiusFactor);
            }
        }

        public void CoinBenefitUp(float val)
        {
            if (_playerCharacter.TryGetComponent(out PlayerUpgrade playerUpgrade))
            {
                _coinBenifitFactor += val * _coinBenifitFactor;
                playerUpgrade.SetCoinBenefitMultiplier(_coinBenifitFactor);
            }
        }

        public void WeaponNextLevel(AttackBulletType type)
        {
            _playerCharacter.AttackUpgrade(type);
        }
        
        public int GetWeaponLevelId(AttackBulletType type)
        {
            return _playerCharacter.GetWeaponLevelId(type);
        }
        
    }
    
    
}